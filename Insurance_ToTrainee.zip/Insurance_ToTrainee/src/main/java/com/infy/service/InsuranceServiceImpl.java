package com.infy.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.exception.InsuranceException;
import com.infy.model.PolicyDTO;
import com.infy.model.PolicyReportDTO;
import com.infy.repository.InsuranceRepository;

@Service
public class InsuranceServiceImpl implements InsuranceService{

    @Autowired
    InsuranceRepository insuranceRepository;
	
	public String buyPolicy(PolicyDTO policy) throws InsuranceException {
		
		return insuranceRepository.buyPolicy(policy);
		
		//return null;
	}

	public Long calculateAge(LocalDate dateOfBirth) throws InsuranceException {
		
		return null;
	}

	public List<PolicyReportDTO> getReport(String policyType) throws InsuranceException {
		
		List<PolicyDTO> list= insuranceRepository.getAllPolicyDetails();
		
		List<PolicyReportDTO> reportlist=new ArrayList();
		
		for( PolicyDTO dto: list) {
			PolicyReportDTO reportDTO=new PolicyReportDTO();
			reportDTO.setPolicyNumber(dto.getPolicyNumber());
			reportDTO.setPolicyHolderName(dto.getPolicyHolderName());
			reportDTO.setPolicyHolderAge(20.00);
			reportDTO.setTenureInMonths(dto.getTenureInMonths());
			reportlist.add(reportDTO);
		}
		
		List<PolicyReportDTO> list123=reportlist.stream().filter(x->x.getPolicyNumber().startsWith("T")).collect(Collectors.toList());
		return list123;
	}

		
	
	
}
