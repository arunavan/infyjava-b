package com.example.productdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductdemoApplication.class, args);
	}

}
