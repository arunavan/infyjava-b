package com.example.productdemo.service;

import java.util.List;

import com.example.productdemo.dto.ProductDTO;
import com.example.productdemo.entity.Product;

public interface ProductService {
	
	public void addPRoduct(ProductDTO productDTO) ;
	public List<ProductDTO> getAllProducts();
	public ProductDTO getProductById(Integer id);
	

}
