package com.example.productdemo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.productdemo.dto.ProductDTO;
import com.example.productdemo.entity.Product;
import com.example.productdemo.repository.ProductRepository;

@Service
@Transactional
public class ProductServiceImpl  implements ProductService{
	@Autowired
	ProductRepository productRepository;
	public void addPRoduct(ProductDTO productDTO) {
		Product product=new Product();
		product.setProductId(productDTO.getProductId());
		product.setName(productDTO.getName());
		product.setPrice(productDTO.getPrice());
		
		productRepository.save(product);
		
	}
	
	public List<ProductDTO> getAllProducts() {
		List<ProductDTO> productDTOlist=new ArrayList<ProductDTO>();
		
		Iterable<Product> plist=productRepository.findAll();  //entity
		plist.forEach(p -> {
			ProductDTO productDTO = new ProductDTO();
			productDTO.setProductId(p.getProductId());  //entity to DTO
			productDTO.setName(p.getName());
			productDTO.setPrice(p.getPrice());
			
			productDTOlist.add(productDTO);
		});
		return productDTOlist;
	}
	
	public ProductDTO getProductById(Integer id) {
		Optional<Product> product=productRepository.findById(id);
		ProductDTO p=new ProductDTO();
		p.setProductId(product.get().getProductId());
		p.setName(product.get().getName());
		p.setPrice(product.get().getPrice());
		return p;
		
	}
	
}
