package com.example.productdemo.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.productdemo.entity.Product;

@Repository
public interface ProductRepository  extends CrudRepository<Product,Integer>{

}
