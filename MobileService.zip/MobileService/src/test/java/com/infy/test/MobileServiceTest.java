package com.infy.test;

import com.infy.service.MobileService;
import com.infy.service.MobileServiceImpl;

public class MobileServiceTest {

    private MobileService mobileService= new MobileServiceImpl();
	public void registerRequestInvalidBrandTest() {
		//your code goes here
	}

	public void registerRequestInvalidContactNumberTest() {
		//your code goes here
	}

	public void registerRequestInvalidIssuesTest() {
		//your code goes here
	}

}
