package com.infy.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.infy.dao.MobileServiceDAO;
import com.infy.dao.MobileServiceDAOImpl;
import com.infy.exception.MobileServiceException;
import com.infy.model.ServiceReport;
import com.infy.model.ServiceRequest;
import com.infy.model.Status;
import com.infy.validator.Validator;

public class MobileServiceImpl implements MobileService{
	
	private MobileServiceDAO dao=new MobileServiceDAOImpl();
	
	private Validator validator=new Validator();
	
	@Override
	public ServiceRequest registerRequest(ServiceRequest service) throws MobileServiceException {
		return null;
	}

	@Override
	public Float calculateEstimateCost(List<String> issues) throws MobileServiceException {
		return null;
	}

	@Override
	public List<ServiceReport> getServices(Status status) throws MobileServiceException {
		
		List<ServiceRequest> newlist= dao.getServices();
		
		List<ServiceRequest> newlist1=newlist.stream().filter(x->x.getStatus().equals(status)).collect(Collectors.toList());
		
		List<ServiceReport> newlist2=new ArrayList<ServiceReport>();
		
		for(ServiceRequest sr:newlist1) {
			ServiceReport sr1=new ServiceReport(sr.getServiceId(),sr.getBrand(),sr.getServiceFee());
			newlist2.add(sr1);
		}
		
		
		return newlist2;
	}

}
