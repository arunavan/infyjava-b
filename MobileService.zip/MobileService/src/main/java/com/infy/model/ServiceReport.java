package com.infy.model;



public class ServiceReport {
	private Integer serviceId;
	private String brand;
	private Float serviceFee;
	
	
	public ServiceReport(Integer serviceId, String brand, Float serviceFee) {
		super();
		this.serviceId = serviceId;
		this.brand = brand;
		this.serviceFee = serviceFee;
	}
	public Integer getServiceId() {
		return serviceId;
	}
	public void setServiceId(Integer serviceId) {
		this.serviceId = serviceId;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public Float getServiceFee() {
		return serviceFee;
	}
	public void setServiceFee(Float serviceFee) {
		this.serviceFee = serviceFee;
	}
	
	
}
