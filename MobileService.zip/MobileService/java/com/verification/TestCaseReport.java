package com.verification;

public class TestCaseReport
{
    public String cadre;
    public String group;
    public String testClass;
    public String testCaseId;
    public String testCaseName;
    public String testCaseDescription;
    public String result;
    public String reasonForFailure;
}