package com.infy.service;

import com.infy.dto.ScholarDTO;

public interface ScholarService {
	
	public void addScholar(ScholarDTO scholarDTO);
	

}
