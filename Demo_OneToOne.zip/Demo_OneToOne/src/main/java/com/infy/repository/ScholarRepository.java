package com.infy.repository;

import org.springframework.data.repository.CrudRepository;

import com.infy.entity.Scholar;

public interface ScholarRepository  extends CrudRepository<Scholar,Integer>{

}
